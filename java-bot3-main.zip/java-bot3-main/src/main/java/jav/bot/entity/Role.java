package jav.bot.entity;

public enum Role {
    ROLE_ADMIN,
    ROLE_MODERATOR,
    ROLE_USER;

    private Role() {
    }
}
