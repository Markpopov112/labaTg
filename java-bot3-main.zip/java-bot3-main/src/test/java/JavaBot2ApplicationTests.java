import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JavaBot2ApplicationTests {
    JavaBot2ApplicationTests() {
    }

    @Test
    void contextLoads() {
    }
}
